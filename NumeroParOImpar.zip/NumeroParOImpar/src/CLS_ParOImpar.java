import java.util.Scanner;

public class CLS_ParOImpar {
	public static void main(String[] args){
		System.out.println("Ingrese un n�mero");
		Scanner en=new Scanner(System.in);
		int numero=en.nextInt();
		if (numero%2==0)
			System.out.println("El n�mero que ingreso es par");
		else
			System.out.println("El numero que ingreso es impar");
				
	}

}
